The EFFIS fuel map was derived in the context of JRC Contract Number 384347 on the “Development of a European Fuel Map”.
Although the original map contained 42 vegetation complexes, these were assigned to the 13 categories of the NFFL or fire behavior models [1].
The last 3 categories of the NFFL models are not used in the European Fuel Map.

The EFFIS fuel map can be downloaded at: https://forest-fire.emergency.copernicus.eu/applications/data-and-services

A legend style in format .QML (e.g. for QGIS) is also enclosed in this archive.


If this EFFIS fuel map is used, we suggest the following way to cite it [2]:

European Forest Fire Information System, 2017. European Fuel Map, based on JRC Contract Number 384347 on the “Development of a European Fuel Map”, European Commission. In: European Forest Fire Information System (EFFIS), Copernicus Emergency Management System.




References

[1] Anderson, H.E., 1982. Aids to determining fuel models for estimating fire behavior ( No. INT-GTR-122), General Technical Report (GTR). U.S.Department of Agriculture, Forest Service, Intermountain Forest and Range Experiment Station, United States. https://doi.org/10.2737/INT-GTR-122

[2] European Forest Fire Information System, 2017. European Fuel Map, based on JRC Contract Number 384347 on the “Development of a European Fuel Map”, European Commission. In: European Forest Fire Information System (EFFIS), Copernicus Emergency Management System.